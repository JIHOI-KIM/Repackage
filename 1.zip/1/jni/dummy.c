void Dummy (void)
{
	return;
}